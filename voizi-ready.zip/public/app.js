const emailInput = document.getElementById("email");
const txt = document.getElementById("txt");
const lang = document.getElementById("lang");
const gen = document.getElementById("gen");
const result = document.getElementById("result");
const status = document.getElementById("status");
const registerBtn = document.getElementById("register");
const clearBtn = document.getElementById("clear");

let currentUser = null;
const LS_KEY = "voizi_user_v2";

function saveLocalUser(u){ localStorage.setItem(LS_KEY, JSON.stringify(u)); }
function loadLocalUser(){ const raw = localStorage.getItem(LS_KEY); return raw?JSON.parse(raw):null; }

function updateUI(){
  const u = loadLocalUser();
  if(u){
    emailInput.value = u.email;
    registerBtn.textContent = "Logged in as " + u.email;
    gen.disabled = false;
    updateStatusText();
  } else {
    registerBtn.textContent = "Register / Login";
    gen.disabled = true;
  }
}

function updateStatusText(){
  const u = loadLocalUser();
  if(!u){ status.textContent = "Free: 2 free for new users • Then 1 every 10 days"; return; }
  if(u.banned){ status.textContent = "You are banned. Contact support."; return; }
  if(u.freeCredits > 0) status.textContent = `Free credits left: ${u.freeCredits}`;
  else if((u.lastFreeUse && (Date.now() - u.lastFreeUse)/(1000*60*60*24) >= 10)) status.textContent = "You can use 1 free voice now (10-day interval).";
  else status.textContent = "Free limit reached. Upgrade to paid plan.";
}

async function register(){
  const email = emailInput.value.trim();
  if(!email) return alert("Enter email");
  try{
    const resp = await fetch("/api/register", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({email})});
    const data = await resp.json();
    if(!resp.ok) return alert(data.error || "Register failed");
    // store minimal user locally
    const user = { email: data.user.email, freeCredits: data.user.freeCredits, lastFreeUse: data.user.lastFreeUse, banned: data.user.banned };
    localStorage.setItem(LS_KEY, JSON.stringify(user));
    updateUI();
    alert("Registered / logged in");
  }catch(e){
    console.error(e); alert("Register error");
  }
}

async function generate(){
  const u = loadLocalUser();
  if(!u) return alert("Register first");
  if(u.banned) return alert("You are banned");
  const text = txt.value.trim();
  if(!text) return alert("Type text");

  // check local free logic quickly
  if(u.freeCredits <=0 && u.lastFreeUse){
    const days = (Date.now() - u.lastFreeUse)/(1000*60*60*24);
    if(days < 10) return alert("Free limit reached. Come back later or upgrade.");
  }

  gen.disabled = true; gen.textContent = "Creating...";
  result.innerHTML = "Processing...";

  try{
    const resp = await fetch("/api/voice", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ email: u.email, text, lang: lang.value })});
    const data = await resp.json();
    if(!resp.ok) throw new Error(data.error || "Failed");
    // refresh user locally by calling register again (quick)
    await register();
    result.innerHTML = `<audio controls src="${data.url}"></audio><p><a href="${data.url}" download="voizi_reel.mp3">Download MP3</a></p>`;
    updateUI();
  }catch(e){
    console.error(e);
    alert(e.message || "Error generating");
  }finally{
    gen.disabled = false; gen.textContent = "🎧 Generate Voice";
  }
}

registerBtn.addEventListener("click", register);
gen.addEventListener("click", generate);
clearBtn.addEventListener("click", ()=>{ txt.value=""; result.innerHTML=""; });

updateUI();
