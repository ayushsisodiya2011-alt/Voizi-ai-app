Voizi - Text to Voice (ready project)
------------------------------------
Files:
- index.js            (backend server)
- package.json
- users.json          (user storage and owner list)
- public/
    - index.html
    - app.js
    - styles.css
    - manifest.json
    - icon-192.png
    - icon-512.png
- storage/            (generated mp3 files will be saved here at runtime)

How to run (Replit):
1. Remix or upload this project to Replit.
2. In the Shell, run: npm install
3. Click Run ▶️
4. Open the provided URL, register with your email, then generate voices.

Notes:
- Owner emails in users.json ownerEmails array get no limits.
- Temp/disposable domains (basic list) are blocked automatically; users registering with such emails are marked banned.
- Payment endpoints are mocked (no real payment integration). Add Razorpay later if needed.

