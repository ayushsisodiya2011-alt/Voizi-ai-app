const express = require("express");
const cors = require("cors");
const gTTS = require("google-tts-api");
const path = require("path");
const fs = require("fs");
const bodyParser = require("body-parser");
const multer = require("multer");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));
app.use('/storage', express.static(path.join(__dirname, "storage")));

const STORAGE_DIR = path.join(__dirname, "storage");
if (!fs.existsSync(STORAGE_DIR)) fs.mkdirSync(STORAGE_DIR);

const USERS_FILE = path.join(__dirname, "users.json");
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify({users:[], bannedDomains:[], ownerEmails:["owner@example.com"]}, null, 2));

function loadUsers(){
  return JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
}
function saveUsers(data){
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2));
}

// Simple temp-mail domains list (not exhaustive)
const TEMP_DOMAINS = [
  "10minutemail.com","tempmail.com","mailinator.com","disposablemail.com","yopmail.com",
  "trashmail.com","guerrillamail.com","maildrop.cc","fakeinbox.com"
];

// Pricing configuration
const PLANS = {
  free: {price:0,monthlyLimit:0}, 
  basic: {price:299,monthlyLimit:10},
  pro: {price:599,monthlyLimit:50},
  studio: {price:2999,monthlyLimit:999999}
};

// helper to find user or create
function findOrCreateUser(email){
  const data = loadUsers();
  let user = data.users.find(u=>u.email===email);
  if(!user){
    user = {
      email,
      plan:"free",
      createdAt: Date.now(),
      freeCredits:2,
      lastFreeUse: null,
      usedThisPeriod: 0,
      banned: false
    };
    data.users.push(user);
    saveUsers(data);
  }
  return user;
}

function isTempDomain(email){
  try{
    const d = email.split("@")[1].toLowerCase();
    return TEMP_DOMAINS.includes(d) || d.includes("mailinator") || d.includes("temp");
  }catch(e){ return false; }
}

// register endpoint
app.post("/api/register", (req,res)=>{
  const { email } = req.body;
  if(!email) return res.status(400).json({error:"Email required"});
  const data = loadUsers();
  // ban if temp domain
  const temp = isTempDomain(email);
  let user = data.users.find(u=>u.email===email);
  if(!user){
    user = { email, plan:"free", createdAt: Date.now(), freeCredits: temp?0:2, lastFreeUse:null, usedThisPeriod:0, banned: temp?true:false };
    data.users.push(user);
    if(temp){
      // add domain to banned list for quick reference
      const domain = email.split("@")[1];
      if(!data.bannedDomains.includes(domain)) data.bannedDomains.push(domain);
    }
    saveUsers(data);
  } else {
    // existing user - if temp domain now, ban
    if(isTempDomain(email)){
      user.banned = true;
      const domain = email.split("@")[1];
      if(!data.bannedDomains.includes(domain)) data.bannedDomains.push(domain);
      saveUsers(data);
    }
  }
  if(user.banned) return res.status(403).json({error:"Temp/Disposable email not allowed. You are banned."});
  return res.json({success:true, user});
});

// subscribe (mock - no real payment)
app.post("/api/subscribe", (req,res)=>{
  const { email, plan } = req.body;
  if(!email || !plan) return res.status(400).json({error:"email and plan required"});
  const data = loadUsers();
  const user = data.users.find(u=>u.email===email);
  if(!user) return res.status(404).json({error:"User not found"});
  if(!PLANS[plan]) return res.status(400).json({error:"Unknown plan"});
  user.plan = plan;
  // for studio (owner-like), set huge limit
  user.usedThisPeriod = 0;
  user.freeCredits = 0;
  saveUsers(data);
  return res.json({success:true, user});
});

// admin: grant owner unlimited
app.post("/api/grant-owner", (req,res)=>{
  const { email } = req.body;
  const data = loadUsers();
  if(!data.ownerEmails.includes(email)){
    data.ownerEmails.push(email);
    saveUsers(data);
  }
  return res.json({success:true, ownerEmails: data.ownerEmails});
});

// generate voice
app.post("/api/voice", async (req,res)=>{
  try{
    const { email, text, lang } = req.body;
    if(!email || !text) return res.status(400).json({error:"email and text required"});
    const data = loadUsers();
    const user = data.users.find(u=>u.email===email);
    if(!user) return res.status(404).json({error:"User not registered"});
    if(user.banned) return res.status(403).json({error:"You are banned"});

    const domain = email.split("@")[1];
    if(data.bannedDomains && data.bannedDomains.includes(domain)) {
      user.banned = true; saveUsers(data);
      return res.status(403).json({error:"Domain banned due to disposable mail"});
    }

    // owner bypass: unlimited
    const isOwner = data.ownerEmails.includes(email);

    // free logic
    if(!isOwner && user.plan==="free"){
      // new user free credits
      if(user.freeCredits > 0){
        user.freeCredits -= 1;
        user.lastFreeUse = Date.now();
      } else {
        // allow one per 10 days
        if(user.lastFreeUse){
          const diffDays = (Date.now() - user.lastFreeUse)/(1000*60*60*24);
          if(diffDays < 10){
            return res.status(403).json({error:`Free limit reached. Come back after ${Math.ceil(10-diffDays)} days.`});
          } else {
            user.lastFreeUse = Date.now();
          }
        } else {
          user.lastFreeUse = Date.now();
        }
      }
    } else {
      // paid plans check usage (basic/pro)
      if(!isOwner && user.plan !== "free"){
        const planConf = PLANS[user.plan] || {monthlyLimit:0};
        if(planConf.monthlyLimit && user.usedThisPeriod >= planConf.monthlyLimit){
          return res.status(403).json({error:"Monthly limit reached. Upgrade plan."});
        } else {
          user.usedThisPeriod = (user.usedThisPeriod || 0) + 1;
        }
      }
    }

    saveUsers(data);

    const code = (lang==="en")?"en":"hi";
    const url = gTTS.getAudioUrl(text, { lang: code, slow:false, host: "https://translate.google.com" });

    // download the mp3 and save to storage
    const fileName = `reel_${Date.now()}.mp3`;
    const filePath = path.join(STORAGE_DIR, fileName);
    const writer = fs.createWriteStream(filePath);
    const https = require("https");
    https.get(url, function(response) {
      response.pipe(writer);
      writer.on('finish', () => {
        writer.close();
        const publicUrl = `/storage/${fileName}`;
        return res.json({success:true, url: publicUrl});
      });
      writer.on('error', (err) => {
        console.error(err);
        return res.status(500).json({error:"Failed to save audio"});
      });
    });

  }catch(err){
    console.error(err);
    res.status(500).json({error:err.message});
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log(`🚀 Voizi backend running on port ${PORT}`));
